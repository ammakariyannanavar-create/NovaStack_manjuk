from flask import Flask, request, render_template, jsonify
import pandas as pd
import numpy as np
import pickle
import os

app = Flask(__name__)

# Form field names (snake_case, used in the HTML form)
form_fields = [
    'age',
    'blood_pressure',
    'cholesterol_level',
    'bmi',
    'smoking',
    'diabetes'
]

# Paths for model artifacts (use absolute paths relative to this file)
BASE_DIR = os.path.dirname(__file__)
MODEL_PATH = os.path.join(BASE_DIR, "logistic_model.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pkl")
IMPUTER_PATH = os.path.join(BASE_DIR, "imputer.pkl")

# Load model and tools
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)
with open(SCALER_PATH, "rb") as f:
    scaler = pickle.load(f)
with open(IMPUTER_PATH, "rb") as f:
    imputer = pickle.load(f)

# Original feature names used when the imputers/encoder were fitted
ORIG_FEATURE_NAMES = list(getattr(imputer, 'feature_names_in_', []))

@app.route("/")
def home():
    return render_template("index.html")   # ✅ MUST RETURN

@app.route("/predict", methods=["POST"])
def predict():
    try:
        form_data = request.form.to_dict()

        # normalize form keys: lower-case and replace spaces with underscores
        normalized = {k.strip().lower().replace(" ", "_"): v for k, v in form_data.items()}

        # Build input DataFrame with the original feature names expected by the pipeline
        input_df = pd.DataFrame(np.nan, index=[0], columns=ORIG_FEATURE_NAMES)

        # Map continuous inputs
        field_map = {
            'age': 'Age',
            'blood_pressure': 'Blood Pressure',
            'cholesterol_level': 'Cholesterol Level',
            'bmi': 'BMI'
        }
        for form_key, col_name in field_map.items():
            val = normalized.get(form_key, "")
            if val != "":
                try:
                    input_df.at[0, col_name] = float(val)
                except Exception:
                    input_df.at[0, col_name] = np.nan

        # Map binary inputs to their one-hot columns expected by the pipeline
        smoking_val = normalized.get('smoking', '')
        if smoking_val != '':
            input_df.at[0, 'Smoking_Yes'] = 1.0 if str(smoking_val) in ('1', '1.0', 'yes', 'true') else 0.0

        diabetes_val = normalized.get('diabetes', '')
        if diabetes_val != '':
            input_df.at[0, 'Diabetes_Yes'] = 1.0 if str(diabetes_val) in ('1', '1.0', 'yes', 'true') else 0.0

        # Now impute, scale and predict
        input_imputed = imputer.transform(input_df)
        input_scaled = scaler.transform(input_imputed)

        raw_pred = model.predict(input_scaled)[0]
        # Handle different prediction types (numeric 0/1 or string 'Yes'/'No')
        if isinstance(raw_pred, (int, float, np.integer, np.floating)):
            prediction = int(raw_pred)
        else:
            prediction = 1 if str(raw_pred).strip().lower() in ('yes', 'heart disease', '1', 'true') else 0

        result = "Heart Disease Detected" if prediction == 1 else "No Heart Disease"

        # Return JSON for AJAX requests
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.accept_mimetypes.accept_json:
            return jsonify({'result': result})

        return render_template("index.html", result=result)

    except Exception as e:
        app.logger.exception('Prediction error')
        msg = 'An error occurred while predicting. Please check input values.'
        # JSON error for AJAX
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.accept_mimetypes.accept_json:
            return jsonify({'error': msg}), 500
        return render_template('index.html', result=msg)

if __name__ == "__main__":
    app.run(debug=True)
